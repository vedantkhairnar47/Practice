#include<iostream>
using namespace std;

int main()
{
    cout<<"Jay Ganesh\n";

    return 0;
}

// g++ program192.cpp -o Myexe
// Myexe.exe
// ./Myexe