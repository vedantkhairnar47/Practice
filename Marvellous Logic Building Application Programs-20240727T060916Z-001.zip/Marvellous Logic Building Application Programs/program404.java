class node
{
    public int data;
    public node next;
}

/*
struct node
{
    int data;
    struct node *next;
};
*/

class SinglyLL
{
    public node First;
    public int iCount;
}

/*
class SinglyLL
{
    public:
        struct node *First;
        int iCount;
}
*/

class program404
{
    public static void main(String Arg[])
    {
        SinglyLL obj = new SinglyLL();      // SinglyLL obj;
    }
}