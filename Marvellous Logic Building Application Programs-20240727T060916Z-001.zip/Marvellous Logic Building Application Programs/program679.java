import java.util.*;

class program679
{
    public static void main(String Arg[])
    {
        System.out.println("Jay ganesh...");        
    }
}
