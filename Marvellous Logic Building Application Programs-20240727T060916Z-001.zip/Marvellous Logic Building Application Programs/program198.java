
class program198
{
    public static void main(String Arg[])
    {
        int iValue1 = 10, iValue2 = 11;
        int iAns = 0;

        iAns = iValue1 + iValue2;

        System.out.println("Addition is : "+iAns);
        
    }
}