class program501
{
    public static void main(String Arg[])
    {
        System.out.println("------- Marvellous Packer Unpacker CUI Module -------");

    }
}