
class program197
{
    public static void main(String Arg[])
    {
        System.out.println("Jay Ganesh");
    }
}

// javac program197.java
// java program197