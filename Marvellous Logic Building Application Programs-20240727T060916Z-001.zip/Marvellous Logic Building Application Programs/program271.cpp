#include<iostream>
using namespace std;

// Approach 3 : Using recurssion

void Display()
{
    int i = 1;

    if(i<= 4)
    {
        cout<<"*"<<endl;
        i++;
    }
}

int main()
{
    Display();

    return 0;
}